from playwright.sync_api import Page, expect


def test_user_login(page: Page) -> None:
    page.goto("https://http.hexlet.app/python-playwright/login")
    page.get_by_label("Username").fill("passenger")
    page.get_by_label("Password").fill("flight321")
    page.get_by_role("button", name="Log in").click()
    expect(page.get_by_role("heading", name="My trips")).to_be_visible(timeout=3000)
